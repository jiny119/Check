function completeTask() { document.getElementById('task-message').innerText = "Task Completed!"; }
